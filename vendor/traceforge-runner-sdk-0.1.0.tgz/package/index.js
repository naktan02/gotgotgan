#!/usr/bin/env node

// packages/runner-sdk/src/forge-sdk.ts
import { spawn } from "node:child_process";
import { randomUUID } from "node:crypto";
import { createInterface } from "node:readline";
var MAX_PROTOCOL_LINE_CHARACTERS = 2 * 1024 * 1024;
var ForgeSdkTransportError = class extends Error {
  constructor(message) {
    super(message);
    this.name = "ForgeSdkTransportError";
  }
};
var ForgeSdk = class _ForgeSdk {
  #child;
  #lines;
  #pending = /* @__PURE__ */ new Map();
  #closed = false;
  #stderr = "";
  constructor(options) {
    this.#child = spawn(options.command, [...options.arguments], {
      ...options.cwd ? { cwd: options.cwd } : {},
      shell: false,
      stdio: ["pipe", "pipe", "pipe"],
      windowsHide: true
    });
    this.#lines = createInterface({ crlfDelay: Infinity, input: this.#child.stdout });
    this.#child.stderr.setEncoding("utf8");
    this.#child.stderr.on("data", (chunk) => {
      this.#stderr = `${this.#stderr}${chunk}`.slice(-8192);
    });
    this.#child.once("exit", () => this.#failAll("Forge Runner exited"));
    this.#child.once("error", () => this.#failAll("Forge Runner could not start"));
  }
  static async start(options) {
    const sdk = new _ForgeSdk(options);
    await sdk.#waitUntilReady(options.startupTimeoutMs ?? 1e4);
    return sdk;
  }
  async run(request) {
    if (this.#closed || !this.#child.stdin.writable) {
      throw new ForgeSdkTransportError("Forge SDK is closed");
    }
    const id = randomUUID();
    const result = new Promise((resolve, reject) => {
      this.#pending.set(id, { reject, resolve });
    });
    const line = `${JSON.stringify({ id, request, type: "run" })}
`;
    if (line.length > MAX_PROTOCOL_LINE_CHARACTERS) {
      this.#pending.delete(id);
      throw new ForgeSdkTransportError("Forge Runner request exceeds the protocol limit");
    }
    this.#child.stdin.write(line, (error) => {
      if (!error) return;
      const pending = this.#pending.get(id);
      this.#pending.delete(id);
      pending?.reject(new ForgeSdkTransportError("Forge Runner request could not be written"));
    });
    return await result;
  }
  async close() {
    if (this.#closed) return;
    this.#closed = true;
    const exited = this.#child.exitCode === null ? new Promise((resolve) => this.#child.once("exit", () => resolve())) : Promise.resolve();
    this.#child.stdin.end();
    let timeout;
    try {
      await Promise.race([
        exited,
        new Promise((resolve) => {
          timeout = setTimeout(resolve, 5e3);
        })
      ]);
    } finally {
      if (timeout) clearTimeout(timeout);
    }
    if (this.#child.exitCode === null) this.#child.kill();
    this.#lines.close();
    this.#failAll("Forge SDK closed");
  }
  async #waitUntilReady(timeoutMs) {
    if (!Number.isSafeInteger(timeoutMs) || timeoutMs <= 0 || timeoutMs > 6e4) {
      throw new ForgeSdkTransportError("Forge SDK startup timeout is invalid");
    }
    await new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        cleanup();
        reject(new ForgeSdkTransportError("Forge Runner startup timed out"));
      }, timeoutMs);
      const onExit = () => {
        cleanup();
        reject(new ForgeSdkTransportError(this.#stderr.trim() || "Forge Runner exited during startup"));
      };
      const onLine = (line) => {
        if (line.length > MAX_PROTOCOL_LINE_CHARACTERS) {
          cleanup();
          reject(new ForgeSdkTransportError("Forge Runner response exceeds the protocol limit"));
          return;
        }
        try {
          const message = JSON.parse(line);
          if (message.type !== "ready" || message.protocolVersion !== 1) return;
          cleanup();
          this.#lines.on("line", (nextLine) => this.#handleLine(nextLine));
          resolve();
        } catch {
          cleanup();
          reject(new ForgeSdkTransportError("Forge Runner startup response is invalid"));
        }
      };
      const cleanup = () => {
        clearTimeout(timeout);
        this.#child.off("exit", onExit);
        this.#lines.off("line", onLine);
      };
      this.#child.once("exit", onExit);
      this.#lines.on("line", onLine);
    }).catch(async (error) => {
      await this.close();
      throw error;
    });
  }
  #handleLine(line) {
    if (line.length > MAX_PROTOCOL_LINE_CHARACTERS) {
      this.#failAll("Forge Runner response exceeds the protocol limit");
      return;
    }
    let message;
    try {
      message = JSON.parse(line);
    } catch {
      this.#failAll("Forge Runner response is invalid");
      return;
    }
    if (typeof message.id !== "string") return;
    const pending = this.#pending.get(message.id);
    if (!pending) return;
    this.#pending.delete(message.id);
    if (message.type === "result") {
      pending.resolve(message.result);
      return;
    }
    pending.reject(new ForgeSdkTransportError(
      typeof message.message === "string" ? message.message : "Forge Runner request failed"
    ));
  }
  #failAll(message) {
    for (const pending of this.#pending.values()) {
      pending.reject(new ForgeSdkTransportError(message));
    }
    this.#pending.clear();
  }
};
export {
  ForgeSdk,
  ForgeSdkTransportError
};
