export type ForgeJson = boolean | null | number | string | readonly ForgeJson[] | {
    readonly [key: string]: ForgeJson;
};
export interface ForgeRunRequest {
    inputs: Readonly<Record<string, ForgeJson>>;
    packId: string;
    packVersion: string;
    recipeId: string;
    version: 1;
}
export type ForgeRunResult = Readonly<{
    outputs: Readonly<Record<string, ForgeJson>>;
    state: 'succeeded';
    version: 1;
}> | Readonly<{
    code: string;
    message: string;
    state: 'failed' | 'needs-user-action';
    version: 1;
}>;
