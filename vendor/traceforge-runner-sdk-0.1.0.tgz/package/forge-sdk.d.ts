import type { ForgeRunRequest, ForgeRunResult } from './protocol.js';
export interface ForgeSdkOptions {
    arguments: readonly string[];
    command: string;
    cwd?: string;
    startupTimeoutMs?: number;
}
export declare class ForgeSdkTransportError extends Error {
    constructor(message: string);
}
export declare class ForgeSdk {
    #private;
    private constructor();
    static start(options: ForgeSdkOptions): Promise<ForgeSdk>;
    run(request: ForgeRunRequest): Promise<ForgeRunResult>;
    close(): Promise<void>;
}
