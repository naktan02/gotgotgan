# Frontend Architecture

제품 이름을 모르는 프론트 의존 경계 검사기다.

```js
import {
  defineFrontendArchitecturePolicy,
  inspectFrontendArchitecture,
} from '@naktan02/frontend-architecture'

const policy = defineFrontendArchitecturePolicy({
  crossOwnerPublicSegments: { features: ['public'] },
  sameLayerDependencies: { platform: { membership: ['auth'] } },
  shellFeaturePublicSegments: ['public'],
})

const violations = await inspectFrontendArchitecture('src', policy)
```

제품별 예외나 레거시 경로는 이 package에 추가하지 않는다. 각 제품 guard가 policy와 추가 검사를
소유한다.

## Policy

| Key | 의미 |
|---|---|
| `aliases` | source root로 해석할 import prefix. 기본값은 `{ '@/': '.' }` |
| `crossOwnerPublicSegments` | 다른 `features`/`domains` owner가 참조할 수 있는 segment |
| `forbiddenTopLevelBuckets` | `src/` 바로 아래에 만들 수 없는 수평 dumping ground |
| `sameLayerDependencies.platform` | platform owner 사이의 명시적 허용 방향 |
| `shellFeaturePublicSegments` | Shell이 feature를 참조할 때 허용되는 공개 segment |

알 수 없는 key는 오류로 처리한다. 공통 계층 규칙 외의 제품별 금지 이름, 파일 위치, 전환 조건은
소비자 guard가 별도로 검사한다.
