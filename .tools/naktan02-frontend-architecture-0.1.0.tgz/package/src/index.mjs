import { readFile, readdir, stat } from 'node:fs/promises'
import path from 'node:path'

const LAYERS = ['app', 'shells', 'features', 'domains', 'platform', 'shared']
const ALLOWED_TARGETS = {
  app: new Set(['shells', 'features', 'domains', 'platform', 'shared']),
  shells: new Set(['features', 'domains', 'platform', 'shared']),
  features: new Set(['domains', 'platform', 'shared']),
  domains: new Set(['platform', 'shared']),
  platform: new Set(['shared']),
  shared: new Set(),
}
const POLICY_KEYS = new Set([
  'aliases',
  'crossOwnerPublicSegments',
  'forbiddenTopLevelBuckets',
  'sameLayerDependencies',
  'shellFeaturePublicSegments',
])
const SOURCE_EXTENSIONS = ['.ts', '.tsx', '.js', '.jsx', '.mts', '.cts', '.mjs', '.cjs']
const IMPORT_PATTERN = /(?:from\s+|import\s*(?:\(\s*)?)['"]([^'"]+)['"]/g

function assertPlainObject(value, name) {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) {
    throw new TypeError(`${name} must be an object`)
  }
}

function stringArray(value, name) {
  if (!Array.isArray(value) || value.some((item) => typeof item !== 'string' || item.length === 0)) {
    throw new TypeError(`${name} must be an array of non-empty strings`)
  }
  return [...new Set(value)]
}

function dependencyTable(value, name) {
  assertPlainObject(value, name)
  return Object.fromEntries(
    Object.entries(value).map(([owner, targets]) => [owner, stringArray(targets, `${name}.${owner}`)]),
  )
}

export function defineFrontendArchitecturePolicy(input = {}) {
  assertPlainObject(input, 'policy')
  for (const key of Object.keys(input)) {
    if (!POLICY_KEYS.has(key)) throw new TypeError(`unknown frontend architecture policy key: ${key}`)
  }

  const aliases = input.aliases ?? { '@/': '.' }
  assertPlainObject(aliases, 'policy.aliases')
  for (const [prefix, target] of Object.entries(aliases)) {
    if (!prefix || typeof target !== 'string') {
      throw new TypeError('policy.aliases must map non-empty prefixes to string paths')
    }
  }

  const crossOwnerPublicSegments = input.crossOwnerPublicSegments ?? {
    features: [],
    domains: [],
  }
  assertPlainObject(crossOwnerPublicSegments, 'policy.crossOwnerPublicSegments')
  for (const layer of Object.keys(crossOwnerPublicSegments)) {
    if (layer !== 'features' && layer !== 'domains') {
      throw new TypeError(`cross-owner public segments are unsupported for layer: ${layer}`)
    }
  }

  const sameLayerDependencies = input.sameLayerDependencies ?? { platform: {} }
  assertPlainObject(sameLayerDependencies, 'policy.sameLayerDependencies')
  for (const layer of Object.keys(sameLayerDependencies)) {
    if (layer !== 'platform') {
      throw new TypeError(`same-layer dependencies are unsupported for layer: ${layer}`)
    }
  }

  return Object.freeze({
    aliases: Object.freeze({ ...aliases }),
    crossOwnerPublicSegments: Object.freeze({
      features: Object.freeze(stringArray(crossOwnerPublicSegments.features ?? [], 'policy.crossOwnerPublicSegments.features')),
      domains: Object.freeze(stringArray(crossOwnerPublicSegments.domains ?? [], 'policy.crossOwnerPublicSegments.domains')),
    }),
    forbiddenTopLevelBuckets: Object.freeze(stringArray(
      input.forbiddenTopLevelBuckets ?? ['components', 'services', 'stores', 'hooks'],
      'policy.forbiddenTopLevelBuckets',
    )),
    sameLayerDependencies: Object.freeze({
      platform: Object.freeze(dependencyTable(
        sameLayerDependencies.platform ?? {},
        'policy.sameLayerDependencies.platform',
      )),
    }),
    shellFeaturePublicSegments: Object.freeze(stringArray(
      input.shellFeaturePublicSegments ?? [],
      'policy.shellFeaturePublicSegments',
    )),
  })
}

async function sourceFiles(directory) {
  const result = []
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const target = path.join(directory, entry.name)
    if (entry.isDirectory()) result.push(...await sourceFiles(target))
    else if (SOURCE_EXTENSIONS.includes(path.extname(entry.name))) result.push(path.resolve(target))
  }
  return result
}

function relative(root, file) {
  return path.relative(root, file).replaceAll('\\', '/')
}

function resolveImport(root, importer, specifier, knownFiles, aliases) {
  let base
  if (specifier.startsWith('.')) {
    base = path.resolve(path.dirname(importer), specifier)
  } else {
    const alias = Object.keys(aliases)
      .sort((left, right) => right.length - left.length)
      .find((prefix) => specifier.startsWith(prefix))
    if (alias === undefined) return undefined
    base = path.resolve(root, aliases[alias], specifier.slice(alias.length))
  }

  const candidates = SOURCE_EXTENSIONS.includes(path.extname(base))
    ? [base]
    : [
        base,
        ...SOURCE_EXTENSIONS.map((extension) => `${base}${extension}`),
        ...SOURCE_EXTENSIONS.map((extension) => path.join(base, `index${extension}`)),
      ]
  return candidates.find((candidate) => knownFiles.has(path.resolve(candidate)))
}

function findCycles(edges) {
  const cycles = []
  const visited = new Set()
  const active = new Set()
  const stack = []

  function visit(node) {
    if (active.has(node)) {
      cycles.push([...stack.slice(stack.indexOf(node)), node])
      return
    }
    if (visited.has(node)) return
    visited.add(node)
    active.add(node)
    stack.push(node)
    for (const target of edges.get(node) ?? []) visit(target)
    stack.pop()
    active.delete(node)
  }

  for (const node of edges.keys()) visit(node)
  return cycles
}

function hasAllowedPublicSegment(targetParts, allowedSegments) {
  return targetParts.length > 2 && allowedSegments.includes(targetParts[2])
}

export async function inspectFrontendArchitecture(rootInput, policyInput = {}) {
  const root = path.resolve(rootInput)
  const policy = defineFrontendArchitecturePolicy(policyInput)
  const violations = []

  for (const bucket of policy.forbiddenTopLevelBuckets) {
    try {
      if ((await stat(path.join(root, bucket))).isDirectory()) {
        violations.push(`forbidden top-level frontend bucket: ${bucket}`)
      }
    } catch (error) {
      if (error?.code !== 'ENOENT') throw error
    }
  }

  const files = await sourceFiles(root)
  const knownFiles = new Set(files)
  const edges = new Map()

  for (const file of files) {
    const importer = relative(root, file)
    const importerParts = importer.split('/')
    const sourceLayer = importerParts[0]
    const targets = []
    const source = await readFile(file, 'utf8')

    for (const match of source.matchAll(IMPORT_PATTERN)) {
      const targetFile = resolveImport(root, file, match[1], knownFiles, policy.aliases)
      if (targetFile === undefined) continue
      const target = relative(root, targetFile)
      targets.push(target)

      const targetParts = target.split('/')
      const targetLayer = targetParts[0]
      if (!LAYERS.includes(sourceLayer) || !LAYERS.includes(targetLayer)) continue

      if (targetLayer !== sourceLayer && !ALLOWED_TARGETS[sourceLayer].has(targetLayer)) {
        violations.push(`${importer}: ${sourceLayer} cannot import ${targetLayer}`)
      }

      if (
        sourceLayer === targetLayer
        && (sourceLayer === 'features' || sourceLayer === 'domains')
        && importerParts[1]
        && targetParts[1]
        && importerParts[1] !== targetParts[1]
        && !hasAllowedPublicSegment(targetParts, policy.crossOwnerPublicSegments[sourceLayer])
      ) {
        violations.push(`${importer}: ${sourceLayer.slice(0, -1)} owners cannot import each other's internals`)
      }

      if (
        sourceLayer === 'platform'
        && targetLayer === 'platform'
        && importerParts[1]
        && targetParts[1]
        && importerParts[1] !== targetParts[1]
        && !(policy.sameLayerDependencies.platform[importerParts[1]] ?? []).includes(targetParts[1])
      ) {
        violations.push(`${importer}: platform owner ${importerParts[1]} cannot import ${targetParts[1]}`)
      }

      if (
        sourceLayer === 'shells'
        && targetLayer === 'features'
        && policy.shellFeaturePublicSegments.length > 0
        && !hasAllowedPublicSegment(targetParts, policy.shellFeaturePublicSegments)
      ) {
        violations.push(`${importer}: shells may import only a feature's public contract`)
      }
    }
    edges.set(importer, targets)
  }

  for (const cycle of findCycles(edges)) {
    violations.push(`frontend import cycle: ${cycle.join(' -> ')}`)
  }
  return [...new Set(violations)].sort()
}
