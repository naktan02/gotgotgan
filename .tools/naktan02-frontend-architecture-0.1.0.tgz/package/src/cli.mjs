#!/usr/bin/env node
import { readFile } from 'node:fs/promises'
import path from 'node:path'
import process from 'node:process'
import { defineFrontendArchitecturePolicy, inspectFrontendArchitecture } from './index.mjs'

function usage() {
  return 'Usage: frontend-architecture-check --root <src> [--config <policy.json>]'
}

function parseArguments(argv) {
  if (argv.includes('--help')) return { help: true }
  const values = {}
  for (let index = 0; index < argv.length; index += 2) {
    const key = argv[index]
    const value = argv[index + 1]
    if (!key?.startsWith('--') || value === undefined) throw new Error(usage())
    if (key !== '--root' && key !== '--config') throw new Error(`unknown option: ${key}`)
    values[key.slice(2)] = value
  }
  if (!values.root) throw new Error('--root is required')
  return values
}

async function main() {
  const args = parseArguments(process.argv.slice(2))
  if (args.help) {
    console.log(usage())
    return
  }
  const policyInput = args.config
    ? JSON.parse(await readFile(path.resolve(args.config), 'utf8'))
    : {}
  const policy = defineFrontendArchitecturePolicy(policyInput)
  const violations = await inspectFrontendArchitecture(path.resolve(args.root), policy)
  if (violations.length > 0) {
    console.error(`Frontend architecture violations:\n${violations.join('\n')}`)
    process.exitCode = 1
    return
  }
  console.log('Frontend architecture valid (0 violations).')
}

main().catch((error) => {
  console.error(error instanceof Error ? error.message : String(error))
  process.exitCode = 1
})
